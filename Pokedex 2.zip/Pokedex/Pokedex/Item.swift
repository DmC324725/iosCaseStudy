//
//  Item.swift
//  Pokedex
//
//  Created by user164946 on 8/26/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import Foundation

class Item:Codable{
    let id : Int
    let name : String
    let sprite : String
    
    init(id:Int, name:String, sprite: String){
        self.id = id
        self.name = name
        self.sprite = sprite
    }
}
