//
//  FirstViewController.swift
//  Pokedex
//
//  Created by user164946 on 8/26/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    

    @IBOutlet weak var tableView: UITableView!
    
    
    
    let pokeURL = "https://pokeapi.co/api/v2/pokemon?limit=1047"
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "pokemoncell", for: indexPath)
        
        return cell;
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "pokemoncell")
        getPokemons(url: pokeURL);
    }
    
    private func getPokemons(url:String){
        URLSession.shared.dataTask(with: URL(string: url)!, completionHandler:{data, response, error in
            guard let data = data, error == nil else{
                print("Something went wrong!")
                return
            }
            var results:PokemonResults?
            do{
                let decoder = JSONDecoder()
                results = try decoder.decode(PokemonResults.self,from: data)
                
            }catch{
                print ("Failed to convert to object")
                
            }
            guard let json = results else{
                return
            }
            print(json.results[0].name)
            }).resume()
        
    }
	
}


