//
//  PokemonResults.swift
//  Pokedex
//
//  Created by user164946 on 8/26/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import Foundation

class PokemonResults:Codable{
    let count: Int
    let next: String?
    let previous: String?
    let results:[ResultItem]
    
}
