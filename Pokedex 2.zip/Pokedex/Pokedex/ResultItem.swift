//
//  ResultItem.swift
//  Pokedex
//
//  Created by user164946 on 8/26/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import Foundation

class ResultItem: Codable{
    let name:String
    let url:String
    
}
