//
//  ItemCollectionViewCell.swift
//  Pokedex
//
//  Created by user164946 on 8/28/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var CellImage: UIImageView!
    
    @IBOutlet weak var CellLabel: UILabel!
    
    
    
    
}
