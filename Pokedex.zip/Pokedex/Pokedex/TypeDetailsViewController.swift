//
//  TypeDetailsViewController.swift
//  Pokedex
//
//  Created by user164946 on 8/29/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class TypeDetailsViewController: UIViewController {
    var type = PokeType()
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var strengthLabel: UILabel!
    @IBOutlet weak var weaknessLabel: UILabel!
    @IBOutlet weak var immuneLabel: UILabel!
    @IBOutlet weak var uselessLabel: UILabel!
    
    
    
    
    func typeString(typePass: [String]?) -> String{
        var myString = ""
        if let type = typePass{
            if(type.count != 0){
                myString = type[0]
            }
            if(type.count>0){
                for i in 1 ..< type.count{
                    myString += ", \(type[i])"
                }
            }
        }
        return myString
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = type.name
        
        //I messed up the values while getting it from the API so names are a little misguiding, but the values are information is accurate!
        weaknessLabel.text = typeString(typePass: type.strong)
        strengthLabel.text = typeString(typePass: type.weak)
        uselessLabel.text = typeString(typePass: type.immune)
        immuneLabel.text = typeString(typePass: type.useless)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
