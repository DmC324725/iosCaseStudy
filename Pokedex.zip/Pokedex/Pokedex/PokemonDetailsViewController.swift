//
//  PokemonDetailsViewController.swift
//  Pokedex
//
//  Created by user164946 on 8/29/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class PokemonDetailsViewController: UIViewController {

    @IBOutlet weak var weightLabel: UILabel!
    
    @IBOutlet weak var hpLabel: UILabel!
    @IBOutlet weak var attackLabel: UILabel!
    @IBOutlet weak var defenseLabel: UILabel!
    
    @IBOutlet weak var spAttackLabel: UILabel!
    
    @IBOutlet weak var spDefenseLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    
    
    @IBOutlet weak var pokemonImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    
    
    
    
    var pokemon = Pokemon()
    
    
    
    
    func typeString(typePass: [String]?) -> String{
        var myString = ""
        if let type = typePass{
            if(type.count != 0){
                myString = type[0]
            }
            for i in 1 ..< type.count{
                myString += ", \(type[i])"
            }
        }
        return myString
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        weightLabel.text = String(pokemon.weight)
        hpLabel.text = String(pokemon.hp)
        attackLabel.text = String(pokemon.attack)
        defenseLabel.text = String(pokemon.defense)
        spAttackLabel.text = String(pokemon.sp_attack)
        spDefenseLabel.text = String(pokemon.sp_defense)
        speedLabel.text = String(pokemon.speed)
        
        pokemonImageView.image = UIImage(named: (String(pokemon.id) + ".png"))
        titleLabel.text = pokemon.name
        typeLabel.text = typeString(typePass: pokemon.types)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
