//
//  PokemonType.swift
//  Pokedex
//
//  Created by user164946 on 8/28/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import Foundation

class PokemonType: Codable{
    
    let id: Int
    let name: String
    let weak: [String]?
    let strong: [String]?
    let immune: [String]?
    let useless: [String]?
}
