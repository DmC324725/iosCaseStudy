//
//  PokemonTableViewController.swift
//  Pokedex
//
//  Created by user164946 on 8/26/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class PokemonTableViewController: UITableViewController {

    let pokeURL = "https://pokeapi.co/api/v2/pokemon?limit=1500"
    var pokemons = [ResultItem]()
    
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pokenames = [Pokemon]()
    
    func getPokemonss(){
        do{
            try self.pokenames = context.fetch(Pokemon.fetchRequest())
            print(pokenames.count)
            if(pokenames.count == 0){
                savePokemonsToCore()
            }else{
            DispatchQueue.main.async {
                self.tableView.reloadData()
                }
                
            }
        }catch{
            print("Failed to fetch pokemons from CoreData")
        }
    }
    
    
    
    
    
    
    func savePokemonsToCore(){
        print("Save Core Function Ran")
        guard let urlPath = Bundle.main.url(forResource: "pokemons", withExtension: "json") else{
            print("Error while fetching Pokemon JSON File")
            return
        }
        print(urlPath)
        
        
        var results:[PokemonItem]?
        do{
            let path = Bundle.main.path(forResource: "pokemons", ofType: "json")
            let data = try Data(contentsOf: URL(fileURLWithPath: path!), options: .mappedIfSafe)
            let decoder = JSONDecoder()
            results = try decoder.decode([PokemonItem].self,from: data)
            for item in results!{
                //Create a Pokemon Object
                let pokemon = Pokemon(context: context)
                pokemon.id = Int64(item.id)
                pokemon.name = item.name
                pokemon.sprite = item.sprite
                pokemon.hp = Int64(item.hp)
                pokemon.attack = Int64(item.attack)
                pokemon.defense = Int64(item.defense)
                pokemon.sp_attack = Int64(item.sp_attack)
                pokemon.sp_defense = Int64(item.sp_defense)
                pokemon.speed = Int64(item.speed)
                pokemon.types = item.types
                pokemon.weight = Int64(item.weight)
                
                
                //Save the object to Core Data
                
                try self.context.save()
                
                    
                
            }
            getPokemonss()
        }catch{
            print ("Failed to convert to object")
            
        }
        
        
    }
    func singleTapAction(_ sender: Any){
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //getPokemons(url: pokeURL)
        getPokemonss()
        
        
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return pokenames.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PokemonCell", for: indexPath) as! PokemonTableViewCell
        cell.pokemonCellTextView.text = pokenames[indexPath.row].name
        cell.pokemonCellImageView.image = UIImage(named: (String(indexPath.row+1) + ".png"))
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        let vc = segue.destination as! PokemonDetailsViewController
        vc.pokemon = pokenames[tableView.indexPathForSelectedRow!.row]
    }
    

}
