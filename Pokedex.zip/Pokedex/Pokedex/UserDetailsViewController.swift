//
//  UserDetailsViewController.swift
//  Pokedex
//
//  Created by user164946 on 8/29/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class UserDetailsViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    var userInfos = [UserInfo]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var userNameLabel: UILabel!
    
     var imagePicker = UIImagePickerController()
    
    
    
    func getUserInfo(){
        do{
            print("Get user info called")
            try self.userInfos = context.fetch(UserInfo.fetchRequest())
            print(userInfos.count)
            if(userInfos.count == 0){
                print("Save info function called")
                saveInfoToCore()
            }else{
                
                //Setting the name and profile from input
                userNameLabel.text = userInfos[0].name
                
                if let profileData = userInfos[0].picture{
                    profileImage.image = UIImage(data: profileData)
                }
                
                
//            DispatchQueue.main.async {
//                self.tableView.reloadData()
//                }
                
            }
        }catch{
            print("Failed to fetch User Info from CoreData")
        }
    }
    
    func saveInfoToCore(){
        
        let userInfo = UserInfo(context: context)
        userInfo.name = "New User"
        do{try self.context.save()
        }catch{
            print("Error while saving new user")
        }
        getUserInfo()
                  
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getUserInfo()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
    profileImage.isUserInteractionEnabled = true
    profileImage.addGestureRecognizer(tapGestureRecognizer)
        
       let tap = UITapGestureRecognizer(target: self, action: #selector(UserDetailsViewController.tapFunction))
    userNameLabel.isUserInteractionEnabled = true
    userNameLabel.addGestureRecognizer(tap)
        
        
        // Do any additional setup after loading the view.
    }
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {

    print("tap working")
        
        let alert = UIAlertController(title: "Name", message: "Please enter your name", preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "Name"
        }

        alert.addAction(UIAlertAction(title: "Submit", style: .default, handler: { [weak alert] (_) in
            guard let textField = alert?.textFields?[0], let userText = textField.text else { return }
            self.userInfos[0].name = userText
            try! self.context.save()
            self.getUserInfo()
        }))

        self.present(alert, animated: true, completion: nil)
}
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
{
    
    // Your action
   ImagePickerManager().pickImage(self){ image in
        //here is the image
    self.profileImage.image = image
    if let data = image.pngData(){
    self.userInfos[0].picture = data
        try! self.context.save()
    }
    }
    
}
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
