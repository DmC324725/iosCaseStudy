//
//  ItemCollectionViewCell.swift
//  Pokedex
//
//  Created by user164946 on 8/28/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionCellImage: UIImageView!
    
    @IBOutlet weak var collectionCellText: UILabel!
    
}
