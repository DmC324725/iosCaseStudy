//
//  PokemonItem.swift
//  Pokedex
//
//  Created by user164946 on 8/28/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import Foundation

class PokemonItem : Codable{
    
    let id: Int
    let name: String
    let sprite: String
    let hp: Int
    let attack: Int
    let defense: Int
    let sp_attack: Int
    let sp_defense: Int
    let speed: Int
    let types: [String]
    let weight: Int
    
    
}
