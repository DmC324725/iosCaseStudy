//
//  PokemonTableViewCell.swift
//  Pokedex
//
//  Created by user164946 on 8/28/20.
//  Copyright © 2020 user164946. All rights reserved.
//

import UIKit

class PokemonTableViewCell: UITableViewCell {
    @IBOutlet weak var pokemonCellTextView: UILabel!
    
    @IBOutlet weak var pokemonCellImageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
